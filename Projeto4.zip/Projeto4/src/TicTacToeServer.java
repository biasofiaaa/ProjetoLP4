import java.io.*;
import java.net.*;
import java.util.*;
import static java.lang.System.out;

public class TicTacToeServer {
    private static final int PORT = 12345; // Porta do servidor
    private static final int SIZE = 3; // Tamanho do tabuleiro
    private final char[][] board = new char[SIZE][SIZE]; // Tabuleiro do jogo
    private final List<Socket> clients = new ArrayList<>(); // Lista de clientes conectados
    private final GameBoard gameBoard = new GameBoard(); // Tabuleiro do jogo encapsulado na classe GameBoard

    public static void main(String[] args) {
        new TicTacToeServer().startServer(); // Inicializa o servidor
    }

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            out.println("Servidor iniciado na porta " + PORT); // Mensagem de início do servidor
            initializeBoard(); // Inicializa o tabuleiro

            while (true) {
                Socket clientSocket = serverSocket.accept(); // Aceita novos clientes
                synchronized (clients) {
                    clients.add(clientSocket); // Adiciona cliente à lista
                }
                new Thread(new ClientHandler(clientSocket)).start(); // Inicia thread para lidar com o cliente

                // Se dois clientes estão conectados, inicia o jogo
                if (clients.size() == 2) {
                    broadcast("O jogo começou! Jogador 1 é 'X' e Jogador 2 é 'O'");
                    broadcast(gameBoard.toString()); // Envia o tabuleiro inicial para os clientes
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Trata exceção de I/O
        }
    }

    private void initializeBoard() {
        for (int i = 0; i < SIZE; i++) {
            Arrays.fill(board[i], ' '); // Preenche o tabuleiro com espaços em branco
        }
    }


    // Converte o tabuleiro para uma string para exibição
    @Override
    public synchronized String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                sb.append(board[i][j]);
                if (j < SIZE - 1) sb.append("|"); // Adiciona separadores de colunas
            }
            sb.append("\n");
            if (i < SIZE - 1) sb.append("-----\n"); // Adiciona separadores de linhas
        }
        return sb.toString();
    }

    // Envia uma mensagem para todos os jogadores conectados
    private void broadcast(String message) {
        synchronized (clients) {
            for (Socket client : clients) {
                try {
                    PrintWriter out = new PrintWriter(client.getOutputStream(), true);
                    out.println(message); // Envia a mensagem para o jogador
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Classe interna para lidar com cada cliente conectado
    private class ClientHandler implements Runnable {
        private Socket clientSocket;  // Socket do cliente
        private char playerSymbol;  // Símbolo do jogador (X ou O)
        private int playerNumber;  // Número do jogador (1 ou 2)
        private String nome; // Nome do Jogador

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
            synchronized (clients) {
                this.playerNumber = clients.indexOf(clientSocket) + 1; // Determina o número do jogador
            }
            this.playerSymbol = (playerNumber == 1) ? 'X' : 'O'; // Define o símbolo do jogador
        }

        public String getNome() {
            return nome; // Retorna o nome do jogador
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                // Pede o nome do jogador
                out.println("Indique o seu nome:");
                nome = in.readLine(); // Lê o nome do jogador

                out.println("Bem-vindo, " + nome + "! és é o Jogador " + playerNumber + " e o teu símbolo é '" + playerSymbol + "'");
                if (playerNumber == 2) {
                    out.println("O jogo está a começar...");
                    broadcast("Jogador 1 (X), faça sua jogada!");
                }

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.equalsIgnoreCase("sair")) {
                        break; // Sai do jogo se o cliente enviar "sair"
                    }

                    // Lê a jogada (linha e coluna)
                    out.println("Indique a linha:");
                    int row = Integer.parseInt(in.readLine());
                    out.println("Indique a coluna:");
                    int col = Integer.parseInt(in.readLine());

                    if (gameBoard.makeMove(row, col, playerSymbol)) {
                        broadcast("Jogador " + playerNumber + " moveu para (" + row + ", " + col + ")");
                        if (gameBoard.checkWin(playerSymbol)) {
                            broadcast("Jogador " + playerNumber + " (" + playerSymbol + ") venceu!");
                            gameBoard.resetBoard();
                            broadcast("Novo jogo começando...");
                        } else if (gameBoard.isFull()) {
                            broadcast("O jogo terminou em empate!");
                            gameBoard.resetBoard();
                            broadcast("Novo jogo começando...");
                        }
                        broadcast(gameBoard.toString()); // Atualiza o tabuleiro para todos os jogadores
                    } else {
                        out.println("Movimento inválido, tente novamente."); //
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private class GameBoard {
        private final char[][] board = new char[SIZE][SIZE]; // Tabuleiro do jogo

        public GameBoard() {
            resetBoard(); // Inicializa o tabuleiro
        }

        public synchronized boolean makeMove(int row, int col, char player) {
            if (board[row][col] == ' ') { // Verifica se a posição está vazia
                board[row][col] = player; // Marca a jogada
                return true;
            }
            return false;
        }

        public synchronized boolean checkWin(char player) {
            for (int i = 0; i < SIZE; i++) {
                if (board[i][0] == player && board[i][1] == player && board[i][2] == player) {
                    return true; // Verifica linhas
                }
                if (board[0][i] == player && board[1][i] == player && board[2][i] == player) {
                    return true; // Verifica colunas
                }
            }
            if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
                return true; // Verifica diagonal principal
            }
            if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
                return true; // Verifica diagonal secundária
            }
            return false;
        }

        public synchronized boolean isFull() {
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    if (board[i][j] == ' ') {
                        return false; // Verifica se há espaços vazios
                    }
                }
            }
            return true; // Tabuleiro cheio
        }

        public synchronized void resetBoard() {
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    board[i][j] = ' '; // Preenche o tabuleiro com espaços em branco
                }
            }
        }

        @Override
        public synchronized String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    sb.append(board[i][j]);
                    if (j < SIZE - 1) sb.append("|"); // Adiciona separadores de colunas
                }
                sb.append("\n");
                if (i < SIZE - 1) sb.append("-----\n"); // Adiciona separadores de linhas
            }
            return sb.toString();
        }
    }
}






