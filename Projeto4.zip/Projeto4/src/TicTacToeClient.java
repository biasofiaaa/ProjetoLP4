import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TicTacToeClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita a porta do servidor
        System.out.print("Digite a porta do servidor (deixe em branco para '12345'): ");
        String portInput = scanner.nextLine().trim();
        int port;
        if (portInput.isEmpty()) {
            port = 12345; // Usa a porta padrão 12345 se não for fornecida
        } else {
            try {
                port = Integer.parseInt(portInput); // Converte a entrada para um número inteiro
            } catch (NumberFormatException e) {
                System.out.println("Porta inválida. Usando a porta padrão '12345'.");
                port = 12345; // Usa a porta padrão em caso de erro
            }
        }

        // Conecta ao servidor usando a porta fornecida
        try (Socket socket = new Socket("localhost", port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            // Solicita o nome do jogador
            System.out.println(in.readLine()); // Mensagem do servidor solicitando o nome
            String name;
            while (true) {
                name = scanner.nextLine().trim();
                if (name.isEmpty()) {
                    System.out.println("Nome não pode estar vazio. Indique o seu nome:");
                } else {
                    break; // Continua se um nome válido for fornecido
                }
            }
            out.println(name); // Envia o nome ao servidor

            // Thread para lidar com mensagens do servidor
            Thread serverMessages = new Thread(() -> {
                try {
                    String serverMessage;
                    while ((serverMessage = in.readLine()) != null) {
                        System.out.println(serverMessage); // Imprime mensagens do servidor
                    }
                } catch (IOException e) {
                    System.out.println("Conexão com o servidor perdida.");
                }
            });
            serverMessages.start(); // Inicia a thread para receber mensagens do servidor

            // Lida com a entrada do usuário
            while (true) {
                String userInput = scanner.nextLine();
                if (userInput.equalsIgnoreCase("sair")) {
                    break; // Sai do loop se o usuário digitar "sair"
                }
                out.println(userInput); // Envia a entrada do usuário ao servidor
            }

            // Fecha o socket e as streams após sair do loop
            socket.close();
            out.close();
            in.close();
            System.out.println("Desconectado do servidor.");
        } catch (IOException e) {
            System.out.println("Não foi possível conectar ao servidor. Por favor, tente novamente mais tarde.");
            e.printStackTrace();
        } finally {
            scanner.close(); // Fecha o scanner
        }
    }
}








